package com.example.transportadora;
import android.app.Activity; import android.os.Bundle; import android.widget.*; import java.util.*;
public class MainActivity extends Activity {
 EditText transportadora,nota,motorista,volume,data,hora,divergencia; TextView registros; ArrayList<String> lista=new ArrayList<>();
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); transportadora=findViewById(R.id.transportadora);nota=findViewById(R.id.nota);motorista=findViewById(R.id.motorista);volume=findViewById(R.id.volume);data=findViewById(R.id.data);hora=findViewById(R.id.hora);divergencia=findViewById(R.id.divergencia);registros=findViewById(R.id.registros);findViewById(R.id.salvar).setOnClickListener(v->salvar());findViewById(R.id.verRegistros).setOnClickListener(v->mostrar());}
 void salvar(){String r="Transportadora: "+transportadora.getText()+"\nNota: "+nota.getText()+"\nMotorista: "+motorista.getText()+"\nVolume: "+volume.getText()+"\nData: "+data.getText()+"  Hora: "+hora.getText()+"\nDivergência: "+divergencia.getText()+"\n--------------------";lista.add(r);Toast.makeText(this,"Registro salvo!",Toast.LENGTH_SHORT).show();transportadora.setText("");nota.setText("");motorista.setText("");volume.setText("");data.setText("");hora.setText("");divergencia.setText("");}
 void mostrar(){if(lista.isEmpty())registros.setText("Nenhum registro salvo.");else{StringBuilder s=new StringBuilder();for(int i=0;i<lista.size();i++)s.append("Registro ").append(i+1).append("\n").append(lista.get(i)).append("\n");registros.setText(s.toString());}}
}
