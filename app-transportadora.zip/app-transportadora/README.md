# App Transportadora
Aplicativo Android básico para registrar nome da transportadora, nota fiscal, motorista, volume, data, hora e divergência.
